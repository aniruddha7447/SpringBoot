import { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './ViewJobs.css';

const ViewJobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const hrUsername = localStorage.getItem('username');
        const response = await axios.get('http://localhost:8080/api/jobs', {
          headers: {
            'HR-Username': hrUsername,
          },
        });
        setJobs(response.data);
      } catch (error) {
        console.error('Error fetching jobs:', error);
        alert('Failed to load jobs');
      } finally {
        setLoading(false);
      }
    };
    fetchJobs();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this job?')) return;

    try {
      const hrUsername = localStorage.getItem('username');
      await axios.delete(`http://localhost:8080/api/jobs/${id}`, {
        headers: {
          'HR-Username': hrUsername,
        },
      });
      setJobs(jobs.filter((job) => job.id !== id));
    } catch (error) {
      console.error('Error deleting job:', error);
      alert('Failed to delete job');
    }
  };

  if (loading) return <div className="loading-jobs">Loading jobs...</div>;

  return (
    <div className="view-jobs-container">
      <h1>Posted Jobs</h1>

      {jobs.length === 0 ? (
        <p className="no-jobs">No jobs available</p>
      ) : (
        <div className="jobs-list">
          {jobs.map((job) => (
            <div key={job.id} className="job-card">
              <h3>{job.title}</h3>
              <p>
                <strong>Location:</strong> {job.location}
              </p>
              <p>
                <strong>Description:</strong> {job.description}
              </p>
              <p>
                <strong>Salary:</strong> {job.salary}
              </p>

              <div className="job-actions">
                <button
                  onClick={() => handleDelete(job.id)}
                  className="delete-btn"
                >
                  Delete
                </button>
                <Link
                  to={`/job-applicants/${job.id}`}
                  className="view-applicants-btn"
                >
                  View Applicants
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ViewJobs;
