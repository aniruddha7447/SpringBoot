import { useState } from 'react';
import axios from 'axios';

const AddJob = ({ onSuccess }) => {
  const [job, setJob] = useState({
    jobTitle: '',
    company: '',
    description: '',
    location: '',
    salary: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setJob((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const hrUsername = localStorage.getItem('username'); // get HR username
      await axios.post('http://localhost:8080/api/jobs', job, {
        headers: {
          'HR-Username': hrUsername,
        },
      });
      alert('Job added successfully!');
      onSuccess();
    } catch (error) {
      console.error('Error adding job:', error);
      alert('Failed to add job');
    }
  };

  return (
    <div className="form-container">
      <h2>Add New Job</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Job Title:</label>
          <input
            type="text"
            name="jobTitle"
            value={job.jobTitle}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Company:</label>
          <input
            type="text"
            name="company"
            value={job.company}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Description:</label>
          <textarea
            name="description"
            value={job.description}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Location:</label>
          <input
            type="text"
            name="location"
            value={job.location}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Salary (rs):</label>
          <input
            type="number"
            name="salary"
            value={job.salary}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className="submit-btn">
          Submit Job
        </button>
      </form>
    </div>
  );
};

export default AddJob;
