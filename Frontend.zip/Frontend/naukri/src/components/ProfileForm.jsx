import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProfileForm = () => {
  const [profile, setProfile] = useState({
    fullName: '',
    contactInfo: '',
    professionalSummary: '',
    education: '',
    technicalSkills: '',
    projects: '',
    internships: '',
    certifications: '',
    languages: '',
    achievements: '',
    extracurricular: '',
    leadership: '',
    workExperience: '',
    profileLinks: '',
    careerInterests: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [message, setMessage] = useState('');

  const username = localStorage.getItem('username'); // get logged-in username

  useEffect(() => {
    if (username) {
      axios
        .get('http://localhost:8080/api/student/profile', {
          headers: {
            'Student-Username': username,
          },
        })
        .then((response) => {
          if (response.data) {
            setProfile(response.data);
            setSubmitted(true);
          }
        })
        .catch((error) => {
          console.error('Error fetching profile:', error);
        });
    }
  }, [username]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile((prevProfile) => ({
      ...prevProfile,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post('http://localhost:8080/api/student/profile', profile, {
        headers: {
          'Student-Username': username,
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setMessage('Profile submitted successfully!');
        setSubmitted(true);
        setProfile(response.data);
      })
      .catch((error) => {
        console.error('Error submitting profile:', error);
        setMessage('Error submitting profile. Please try again.');
      });
  };

  if (submitted) {
    return (
      <div>
        <h2>Student Profile</h2>
        {message && <p>{message}</p>}
        <p>
          <strong>Full Name:</strong> {profile.fullName}
        </p>
        <p>
          <strong>Contact Info:</strong> {profile.contactInfo}
        </p>
        <p>
          <strong>Professional Summary:</strong> {profile.professionalSummary}
        </p>
        <p>
          <strong>Education:</strong> {profile.education}
        </p>
        <p>
          <strong>Technical Skills:</strong> {profile.technicalSkills}
        </p>
        <p>
          <strong>Projects:</strong> {profile.projects}
        </p>
        <p>
          <strong>Internships:</strong> {profile.internships}
        </p>
        <p>
          <strong>Certifications:</strong> {profile.certifications}
        </p>
        <p>
          <strong>Languages:</strong> {profile.languages}
        </p>
        <p>
          <strong>Achievements:</strong> {profile.achievements}
        </p>
        <p>
          <strong>Extracurricular:</strong> {profile.extracurricular}
        </p>
        <p>
          <strong>Leadership:</strong> {profile.leadership}
        </p>
        <p>
          <strong>Work Experience:</strong> {profile.workExperience}
        </p>
        <p>
          <strong>Profile Links:</strong> {profile.profileLinks}
        </p>
        <p>
          <strong>Career Interests:</strong> {profile.careerInterests}
        </p>

        <button onClick={() => setSubmitted(false)}>Edit Profile</button>
      </div>
    );
  }

  return (
    <div>
      <h2>Enter Student Profile</h2>
      {message && <p>{message}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={profile.fullName}
          onChange={handleChange}
          required
        />
        <br />

        <input
          type="text"
          name="contactInfo"
          placeholder="Contact Info"
          value={profile.contactInfo}
          onChange={handleChange}
          required
        />
        <br />

        <textarea
          name="professionalSummary"
          placeholder="Professional Summary"
          value={profile.professionalSummary}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="education"
          placeholder="Education"
          value={profile.education}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="technicalSkills"
          placeholder="Technical Skills"
          value={profile.technicalSkills}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="projects"
          placeholder="Projects"
          value={profile.projects}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="internships"
          placeholder="Internships"
          value={profile.internships}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="certifications"
          placeholder="Certifications"
          value={profile.certifications}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="languages"
          placeholder="Languages"
          value={profile.languages}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="achievements"
          placeholder="Achievements"
          value={profile.achievements}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="extracurricular"
          placeholder="Extracurricular"
          value={profile.extracurricular}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="leadership"
          placeholder="Leadership"
          value={profile.leadership}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="workExperience"
          placeholder="Work Experience"
          value={profile.workExperience}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="profileLinks"
          placeholder="Profile Links"
          value={profile.profileLinks}
          onChange={handleChange}
        />
        <br />

        <input
          type="text"
          name="careerInterests"
          placeholder="Career Interests"
          value={profile.careerInterests}
          onChange={handleChange}
        />
        <br />

        <button type="submit">Submit Profile</button>
      </form>
    </div>
  );
};

export default ProfileForm;
