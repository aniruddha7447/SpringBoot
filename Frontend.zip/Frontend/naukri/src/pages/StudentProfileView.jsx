import { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import './StudentProfileView.css';

const StudentProfileView = () => {
  const { username } = useParams();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/api/student/profile/${username}`
        );
        setProfile(response.data);
      } catch (error) {
        console.error('Error fetching profile:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, [username]);

  const handleBack = () => {
    navigate(-1); // Go back to previous page
  };

  if (loading) return <div className="loading">Loading profile...</div>;
  if (!profile) return <div className="not-found">Profile not found</div>;

  return (
    <div className="profile-view-container">
      <button onClick={handleBack} className="back-btn">
        &larr; Back to Applicants
      </button>

      <h2>Student Profile: {profile.fullName || username}</h2>

      <div className="profile-sections">
        <div className="profile-section">
          <h3>Contact Information</h3>
          <p>
            <strong>Email/Phone:</strong>{' '}
            {profile.contactInfo || 'Not provided'}
          </p>
          <p>
            <strong>Profile Links:</strong>{' '}
            {profile.profileLinks || 'Not provided'}
          </p>
        </div>

        <div className="profile-section">
          <h3>Professional Summary</h3>
          <p>{profile.professionalSummary || 'Not provided'}</p>
        </div>

        <div className="profile-section">
          <h3>Education</h3>
          <pre>{profile.education || 'Not provided'}</pre>
        </div>

        <div className="profile-section">
          <h3>Technical Skills</h3>
          <p>{profile.technicalSkills || 'Not provided'}</p>
        </div>

        <div className="profile-section">
          <h3>Projects</h3>
          <pre>{profile.projects || 'Not provided'}</pre>
        </div>

        <div className="profile-section">
          <h3>Experience</h3>
          <p>
            <strong>Internships:</strong>
          </p>
          <pre>{profile.internships || 'Not provided'}</pre>
          <p>
            <strong>Work Experience:</strong>
          </p>
          <pre>{profile.workExperience || 'Not provided'}</pre>
        </div>

        <div className="profile-section">
          <h3>Additional Information</h3>
          <p>
            <strong>Certifications:</strong>{' '}
            {profile.certifications || 'Not provided'}
          </p>
          <p>
            <strong>Languages:</strong> {profile.languages || 'Not provided'}
          </p>
          <p>
            <strong>Achievements:</strong>{' '}
            {profile.achievements || 'Not provided'}
          </p>
          <p>
            <strong>Extracurricular Activities:</strong>{' '}
            {profile.extracurricular || 'Not provided'}
          </p>
          <p>
            <strong>Leadership Experience:</strong>{' '}
            {profile.leadership || 'Not provided'}
          </p>
        </div>

        <div className="profile-section">
          <h3>Career Interests</h3>
          <p>{profile.careerInterests || 'Not provided'}</p>
        </div>
      </div>
    </div>
  );
};

export default StudentProfileView;
