import { useEffect, useState } from 'react';
import axios from 'axios';

const ViewJobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [appliedStudents, setAppliedStudents] = useState([]);
  const [viewingJobId, setViewingJobId] = useState(null);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const hrUsername = localStorage.getItem('username');
        const response = await axios.get('http://localhost:8080/api/jobs', {
          headers: {
            'HR-Username': hrUsername,
          },
        });
        setJobs(response.data);
      } catch (error) {
        console.error('Error fetching jobs:', error);
        alert('Failed to load jobs');
      } finally {
        setLoading(false);
      }
    };
    fetchJobs();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this job?')) return;

    try {
      const hrUsername = localStorage.getItem('username');
      await axios.delete(`http://localhost:8080/api/jobs/${id}`, {
        headers: {
          'HR-Username': hrUsername,
        },
      });
      setJobs(jobs.filter((job) => job.id !== id));
    } catch (error) {
      console.error('Error deleting job:', error);
      if (error.response && error.response.status === 500) {
        alert(
          'Cannot delete job because there are applications associated with it.'
        );
      } else {
        alert('Failed to delete job');
      }
    }
  };

  const handleView = async (jobId) => {
    try {
      setViewingJobId(jobId);
      const hrUsername = localStorage.getItem('username');
      const response = await axios.get(
        `http://localhost:8080/api/jobs/${jobId}/applicants`,
        {
          headers: {
            'HR-Username': hrUsername,
          },
        }
      );
      setAppliedStudents(response.data);
    } catch (error) {
      console.error('Error fetching applicants:', error);
      alert('Failed to load applicants');
    }
  };

  return (
    <div>
      <h1>Posted Jobs</h1>

      {loading ? (
        <p>Loading jobs...</p>
      ) : jobs.length === 0 ? (
        <p>No jobs available</p>
      ) : (
        <div>
          {jobs.map((job) => (
            <div key={job.id}>
              <h3>{job.jobTitle}</h3>{' '}
              {/* Changed from job.title to job.jobTitle */}
              <p>Company: {job.company}</p>
              <p>Location: {job.location}</p>
              <p>Description: {job.description}</p>
              <p>Salary: {job.salary}</p>
              <button onClick={() => handleDelete(job.id)}>Delete</button>
              <button onClick={() => handleView(job.id)}>
                View Applicants
              </button>
              <hr />
            </div>
          ))}
        </div>
      )}

      {viewingJobId && (
        <div>
          <h2>Students Applied for Job ID: {viewingJobId}</h2>
          {appliedStudents.length === 0 ? (
            <p>No applications yet.</p>
          ) : (
            <ul>
              {appliedStudents.map((student) => (
                <li key={student.id}>
                  {student.studentUsername} -{' '}
                  {student.profile?.fullName || 'No profile'}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};

export default ViewJobs;
