import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AddJob from '../components/AddJob';

function HrDashboard() {
  const [username, setUsername] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const storedName = localStorage.getItem('username');
    const role = localStorage.getItem('role');

    // Redirect if not HR
    if (role !== 'hr') {
      navigate('/login');
    } else {
      setUsername(storedName || 'HR User');
    }
  }, [navigate]);

  const handleAddJobSuccess = () => {
    setShowAddForm(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('username');
    localStorage.removeItem('role'); // or token if used
    navigate('/login'); // Redirect to Login.jsx
  };

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <h1>Welcome HR {username}</h1>
        <button onClick={handleLogout} className="logout-btn">
          Logout
        </button>
      </div>

      <div style={{ margin: '20px 0', display: 'flex', gap: '10px' }}>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="primary-btn"
        >
          {showAddForm ? 'Cancel' : 'ADD JOBS'}
        </button>

        <button
          onClick={() => navigate('/view-jobs')}
          className="secondary-btn"
        >
          VIEW JOBS
        </button>
      </div>

      {showAddForm && (
        <div style={{ marginTop: '30px' }}>
          <AddJob onSuccess={handleAddJobSuccess} />
        </div>
      )}
    </div>
  );
}

export default HrDashboard;
