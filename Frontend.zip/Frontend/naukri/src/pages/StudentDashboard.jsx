import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import JobItem from '../components/JobItem';
import ProfileForm from '../components/ProfileForm';

function StudentDashboard() {
  const [username, setUsername] = useState('');
  const [activeTab, setActiveTab] = useState('available');
  const [availableJobs, setAvailableJobs] = useState([]);
  const [appliedJobs, setAppliedJobs] = useState([]);
  const [rejectedJobs, setRejectedJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const storedName = localStorage.getItem('username');
    const role = localStorage.getItem('role');

    if (role !== 'student') {
      navigate('/login');
    } else {
      setUsername(storedName || 'Student User');
      fetchJobs();
    }
  }, [navigate]);

  const fetchJobs = async () => {
    setLoading(true);
    try {
      const studentUsername = localStorage.getItem('username');

      const [availableRes, appliedRes, rejectedRes] = await Promise.all([
        axios.get('http://localhost:8080/api/student/jobs/available', {
          headers: { 'Student-Username': studentUsername },
        }),
        axios.get('http://localhost:8080/api/student/jobs/applied', {
          headers: { 'Student-Username': studentUsername },
        }),
        axios.get('http://localhost:8080/api/student/jobs/rejected', {
          headers: { 'Student-Username': studentUsername },
        }),
      ]);

      setAvailableJobs(availableRes.data);
      setAppliedJobs(appliedRes.data.map((app) => app.job));
      setRejectedJobs(rejectedRes.data.map((app) => app.job));
    } catch (error) {
      console.error('Error fetching jobs:', error);
      alert('Failed to load jobs');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async (jobId) => {
    setActionLoading(true);
    try {
      const studentUsername = localStorage.getItem('username');
      await axios.post(
        `http://localhost:8080/api/student/jobs/apply?jobId=${jobId}`,
        null,
        { headers: { 'Student-Username': studentUsername } }
      );
      await fetchJobs();
    } catch (error) {
      console.error('Error applying for job:', error);
      if (error.response && error.response.status === 400) {
        alert('You have already applied or rejected this job');
      } else {
        alert('Failed to apply for job');
      }
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async (jobId) => {
    setActionLoading(true);
    try {
      const studentUsername = localStorage.getItem('username');
      await axios.post(
        `http://localhost:8080/api/student/jobs/reject?jobId=${jobId}`,
        null,
        { headers: { 'Student-Username': studentUsername } }
      );
      await fetchJobs();
    } catch (error) {
      console.error('Error rejecting job:', error);
      if (error.response && error.response.status === 400) {
        alert('You have already applied or rejected this job');
      } else {
        alert('Failed to reject job');
      }
    } finally {
      setActionLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    navigate('/login');
  };

  const renderJobList = (jobs, showActions = false) => {
    if (loading) return <div className="loading-spinner">Loading...</div>;

    if (jobs.length === 0) {
      return <p className="no-jobs-message">No jobs found in this category</p>;
    }

    return (
      <div className="jobs-grid">
        {jobs.map((job) => (
          <JobItem
            key={job.id}
            job={job}
            showActions={showActions}
            onApply={handleApply}
            onReject={handleReject}
            isProcessing={actionLoading}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h1>Welcome, {username}</h1>
        <button onClick={handleLogout} className="logout-btn">
          Logout
        </button>
      </div>

      <div className="tabs-container">
        <button
          onClick={() => setActiveTab('available')}
          className={`tab ${activeTab === 'available' ? 'active' : ''}`}
        >
          Available Jobs
        </button>
        <button
          onClick={() => setActiveTab('applied')}
          className={`tab ${activeTab === 'applied' ? 'active' : ''}`}
        >
          Applied Jobs
        </button>
        <button
          onClick={() => setActiveTab('rejected')}
          className={`tab ${activeTab === 'rejected' ? 'active' : ''}`}
        >
          Rejected Jobs
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`tab ${activeTab === 'profile' ? 'active' : ''}`}
        >
          My Profile
        </button>
      </div>

      <div className="content-section">
        {activeTab === 'available' && (
          <>
            <h2>Available Jobs</h2>
            {renderJobList(availableJobs, true)}
          </>
        )}

        {activeTab === 'applied' && (
          <>
            <h2>Applied Jobs</h2>
            {renderJobList(appliedJobs)}
          </>
        )}

        {activeTab === 'rejected' && (
          <>
            <h2>Rejected Jobs</h2>
            {renderJobList(rejectedJobs)}
          </>
        )}

        {activeTab === 'profile' && (
          <>
            <h2>My Profile</h2>
            <ProfileForm />
          </>
        )}
      </div>
    </div>
  );
}

export default StudentDashboard;
