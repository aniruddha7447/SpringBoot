package com.example.demo.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entiry.Job;

public interface JobRepository extends JpaRepository<Job, Long> {

	List<Job> findByHrUsername(String hrUsername);

	Optional<Job> findByIdAndHrUsername(Long id, String hrUsername);

	@Query("SELECT CASE WHEN COUNT(j) > 0 THEN true ELSE false END FROM Job j WHERE j.id = :id AND j.hrUsername = :hrUsername")
	boolean existsByIdAndHrUsername(@Param("id") Long id, @Param("hrUsername") String hrUsername);
}
