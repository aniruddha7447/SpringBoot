package com.example.demo.entiry;

public enum ApplicationStatus {
    APPLIED,
    INTERVIEW_SCHEDULED,
    SHORTLISTED,
    REJECTED
}