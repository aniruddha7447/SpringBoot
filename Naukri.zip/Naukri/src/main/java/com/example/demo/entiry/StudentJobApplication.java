package com.example.demo.entiry;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class StudentJobApplication {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "profile_id")
	private StudentProfile profile;

	@ManyToOne
	@JoinColumn(name = "job_id")
	private Job job;

	private String studentUsername;

	private String interviewDate;
	private String interviewTime;
	

	public StudentJobApplication(Long id, StudentProfile profile, Job job, String studentUsername, String interviewDate,
			String interviewTime, ApplicationStatus status) {
		super();
		this.id = id;
		this.profile = profile;
		this.job = job;
		this.studentUsername = studentUsername;
		this.interviewDate = interviewDate;
		this.interviewTime = interviewTime;
		this.status = status;
	}

	public String getInterviewDate() {
		return interviewDate;
	}

	public void setInterviewDate(String interviewDate) {
		this.interviewDate = interviewDate;
	}

	public String getInterviewTime() {
		return interviewTime;
	}

	public void setInterviewTime(String interviewTime) {
		this.interviewTime = interviewTime;
	}

	@Enumerated(EnumType.STRING)
	private ApplicationStatus status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudentProfile getProfile() {
		return profile;
	}

	public void setProfile(StudentProfile profile) {
		this.profile = profile;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public String getStudentUsername() {
		return studentUsername;
	}

	public void setStudentUsername(String studentUsername) {
		this.studentUsername = studentUsername;
	}

	public ApplicationStatus getStatus() {
		return status;
	}

	public void setStatus(ApplicationStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "StudentJobApplication [id=" + id + ", profile=" + profile + ", job=" + job + ", studentUsername="
				+ studentUsername + ", status=" + status + "]";
	}

	public StudentJobApplication(Long id, StudentProfile profile, Job job, String studentUsername,
			ApplicationStatus status) {
		super();
		this.id = id;
		this.profile = profile;
		this.job = job;
		this.studentUsername = studentUsername;
		this.status = status;
	}

	public StudentJobApplication() {
		super();
		
	}

}
